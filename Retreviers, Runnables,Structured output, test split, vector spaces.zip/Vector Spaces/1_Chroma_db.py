from langchain_huggingface import HuggingFaceEmbeddings
from dotenv import load_dotenv
# from langchain.vectorstores import Chroma
from langchain_community.vectorstores import Chroma

import os   
load_dotenv()
# embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")

from langchain.schema import Document

doc1 = Document(
    page_content="Virat Kohli is one of the greatest modern-day batsmen, known for his aggressive style and consistency in run-chases.",
    metadata={"team": "RCB"}
)

doc2 = Document(
    page_content="MS Dhoni is renowned for his calm captaincy, sharp wicketkeeping skills, and his ability to finish matches under pressure.",
    metadata={"team": "CSK"}
)

doc3 = Document(
    page_content="Rohit Sharma, the 'Hitman', is famous for his effortless six-hitting and record of multiple double centuries in ODIs.",
    metadata={"team": "MI"}
)

doc4 = Document(
    page_content="AB de Villiers, also called 'Mr. 360', was loved for his innovative stroke play and ability to hit shots all around the ground.",
    metadata={"team": "RCB"}
)

doc5 = Document(
    page_content="Rashid Khan, the Afghan spinner, is one of the most successful T20 bowlers, known for his sharp googly and quick leg-spin.",
    metadata={"team": "GT"}
)


lst_docs=[doc1,doc2,doc3,doc4,doc5]

vector_stores = Chroma(
    embedding_function=HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2"),
    persist_directory="chroma_db",
    collection_name='sample'
)

vector_stores.add_documents(lst_docs)

print(vector_stores.get(include=['embeddings','documents','metadatas']))

print("***************************************")


print(vector_stores.similarity_search(
    query="who among these are a bowler?",
    k=2
))

print("***************************************")


print(vector_stores.similarity_search_with_score(
    query="who among these are a bowler?",
    k=2
))

#metadat filtring

print("***************************************")


print(vector_stores.similarity_search_with_score(
    query="",
    filter={"team": "RCB"}
))

#update doc
update_doc1= Document(
    page_content="my name is anas khan",
    metadata={"team" : "Musakhel"}
)

# vector_stores.update_document(document_id='ddd56019-548a-4ca1-865b-6734f7dfc6fb', document=update_doc1)


print()

print("**************************")


print(vector_stores.get(include=['embeddings','documents','metadatas']))


vector_stores.delete(ids=['ddd56019-548a-4ca1-865b-6734f7dfc6fb'])


print("**************************")


print(vector_stores.get(include=['embeddings','documents','metadatas']))



