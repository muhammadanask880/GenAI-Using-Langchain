from langchain_huggingface import ChatHuggingFace, HuggingFaceEndpoint
from dotenv import load_dotenv
load_dotenv()
from typing import TypedDict, Annotated, Optional, Literal
model = HuggingFaceEndpoint(repo_id="meta-llama/Llama-3.1-8B-Instruct", task="text-generation")
llm = ChatHuggingFace(llm=model)

#schema
class Review(TypedDict):
    summary: str
    # another method to add description
    # summary: Annotated[str, "A brief summary of the movie plot."]
    sentiment: str
    # another method to add description use of literal
    # sentiment: Annotated[Literal["Pos", "Neg"], "The overall sentiment of the movie review."]
    key_themes: Annotated[list[str], "A list of key themes in the movie."]
    pros: Annotated[Optional[list[str]], "A list of positive aspects of the movie."]
 

structured_output_model = llm.with_structured_output(Review)

result = structured_output_model.invoke("give me what is asked about this movie, 'Inception'.")
print(result)  # {'summary': 'Inception is a mind-bending thriller that explores the concept of dreams within dreams.', 'sentiment': 'Positive'}

