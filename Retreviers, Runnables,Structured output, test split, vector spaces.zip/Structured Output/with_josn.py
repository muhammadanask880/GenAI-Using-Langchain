from langchain_huggingface import ChatHuggingFace, HuggingFaceEndpoint
from dotenv import load_dotenv
load_dotenv()

model = HuggingFaceEndpoint(repo_id="meta-llama/Llama-3.1-8B-Instruct", task="text-generation")
llm = ChatHuggingFace(llm=model)

# JSON schema with title + description
json_schemaa = {
    "title": "MovieReview",
    "description": "Structured output for summarizing and analyzing a movie.",
    "type": "object",
    "properties": {
        "summary": {
            "type": "string",
            "description": "A brief summary of the movie plot."
        },
        "sentiment": {
            "type": "string",
            "enum": ["Positive", "Negative", "Neutral"],
            "description": "The overall sentiment of the movie review."
        }
    },
    "required": ["summary", "sentiment"]
}

structured_output_model = llm.with_structured_output(json_schemaa)

result = structured_output_model.invoke("give me what is asked about this movie, 'Inception'.")
print(result)

