#pydantic allo wthat datatype validation and structured output
#if you define str and enter int it will give error

#coerce data to the right type
#for example if you define age as int and enter age as "25" it will convert it to int 25
 
#there are some vlaidation in pydantic like email validation
# if you define email as EmailStr and enter invalid email it will give error
from pydantic import BaseModel, EmailStr, Field
from typing import Optional
class Student(BaseModel):
    name: str 
    #another method of adding direct default value
    # name: str = Field(..., description="The full name of the student.")
    #OR
    # name: str = "anus"
    age: Optional[int] = None
    email: EmailStr
    cgpa : float= Field(ge=0.0, le=4.0, default=0.0) #cgpa should be between 0.0 to 4.0
# *********************
new_student = {"name": "Alice Johnson", "age": 21, "email": "abc@gmail.com", "cgpa": 3.8}
# for adding direct by default value leave it emoty like
# new_student = {}
# ********************* 
student = Student(**new_student)

# print(student)
#if many attributes are there and you want to print only one attribute
# print(student.name) and etc
print(student.name, student.age, student.email,student.cgpa)

#to convert to dict and json
# student_dict = dict(student)  
# print(student_dict)
# student_json = student.model_dump_json()
# print(student_json)