class NakiliLLMChain:
    def __init__(self, llm, prompt ):
        self.llm = llm
        self.prompt = prompt
    

    def run(self, input_dict):
        # Process input data through the LLM chain
        final_prompt= self.prompt.format(input_dict)
        result= self.llm.predict(final_prompt)
        return result['response']
    
class NakliPromptTemplate:
    def __init__(self, template, input_variables):
        self.template = template
        self.input_variables = input_variables

    def format(self, input_dict):
        return self.template.format(**input_dict)

import random
class NakliLLM:
    def __init__(self):
        print("LLM Created")
    
    def predict(self, prompt):
        response = [
            'Delhi is capital of india',
            "IPL is cricker leauge",
            "Python is a great programming language"
        ]
        return {'response': random.choice(response)}
    

template=NakliPromptTemplate(template="What is capital of {country}?", input_variables=["country"])

llm = NakliLLM()

chain=NakiliLLMChain(llm,template)
res=chain.run({"country": "india"})
print(res)
