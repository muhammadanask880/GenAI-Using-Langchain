import random
class NakliLLM:
    def __init__(self):
        print("LLM Created")
    
    def predict(self, prompt):
        response = [
            'Delhi is capital of india',
            "IPL is cricker leauge",
            "Python is a great programming language"
        ]
        return {'response': random.choice(response)}
    

class NakliPromptTemplate:
    def __init__(self, template, input_variables):
        self.template = template
        self.input_variables = input_variables

    def format(self, input_dict):
        return self.template.format(**input_dict)
    
template=NakliPromptTemplate(template="What is capital of {country}?", input_variables=["country"])
formatted_prompt=template.format({"country": "india"})


llm = NakliLLM()

ans=llm.predict(formatted_prompt)
print(ans['response'])    
# print(formatted_prompt)
