import random
from abc import ABC, abstractmethod

class Runnable(ABC):
    @abstractmethod
    def invoke(input_data):
        pass


class NakliPromptTemplate(Runnable):
    def __init__(self, template, input_variables):
        self.template = template
        self.input_variables = input_variables
    
    def invoke(self,input_dict):
        return self.template.format(**input_dict)

    def format(self, input_dict):
        return self.template.format(**input_dict)

class NakliLLM(Runnable):
    def __init__(self):
        print("LLM Created")

    def invoke(self, prompt):
        response = [
            'Delhi is capital of india',
            "IPL is cricker leauge",
            "Python is a great programming language"
        ]
        return {'response': random.choice(response)}
    
        
    def predict(self, prompt):
        response = [
            'Delhi is capital of india',
            "IPL is cricker leauge",
            "Python is a great programming language"
        ]
        return {'response': random.choice(response)}
    

class runnable_connecter(Runnable):
    def __init__(self, runnable_list):
        self.runnable_list=runnable_list
    
    def invoke(self, input_data):

        for run in self.runnable_list:
            input_data=run.invoke(input_data)
        return input_data
    
template= NakliPromptTemplate(
    template="write a {length} poem about {topic}",
    input_variables=['length','topic']
)

llm= NakliLLM()

chain=runnable_connecter([template,llm])

ans=chain.invoke({'length': 'long', 'topic': 'pak'})

print(ans)