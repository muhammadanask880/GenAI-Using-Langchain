from langchain_huggingface import ChatHuggingFace, HuggingFaceEndpoint
from dotenv import load_dotenv
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain.schema.runnable import RunnableSequence , RunnableParallel , RunnablePassthrough, RunnableLambda , RunnableBranch
load_dotenv()

llm1= HuggingFaceEndpoint(repo_id="meta-llama/Llama-3.1-8B-Instruct", task="text-generation",
                         max_new_tokens=10)     
model = ChatHuggingFace(llm=llm1)
parser= StrOutputParser()

def word(text):
    x = len(text.split())
    return x

template1 = PromptTemplate(
    template="generate a joke about {topic}",
    input_variables=['topic']
)

template2 = PromptTemplate(
    template="say that this joke is very nice {joke}",
    input_variables=["joke"]
)

template3 = PromptTemplate(
    template="say that this joke is very bad {joke}",
    input_variables=["joke"]
)

joke_gen_chain= RunnableSequence(template1,model,parser)

branch_chain =RunnableBranch(
    (lambda x : word(x) > 5, RunnableSequence(template2,model,parser)),
    # (lambda x : word(x) < 500, RunnableSequence(template3,model,parser))
    RunnableSequence(template3,model,parser)
)


final_chain = joke_gen_chain | branch_chain

res= final_chain.invoke({"topic": "AI"})
print(res)


