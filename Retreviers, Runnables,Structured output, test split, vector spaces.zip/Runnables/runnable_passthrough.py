from langchain_huggingface import ChatHuggingFace, HuggingFaceEndpoint
from dotenv import load_dotenv
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain.schema.runnable import RunnableSequence , RunnableParallel , RunnablePassthrough
load_dotenv()

llm1= HuggingFaceEndpoint(repo_id="meta-llama/Llama-3.1-8B-Instruct", task="text-generation",
                         max_new_tokens=10)     
model = ChatHuggingFace(llm=llm1)
parser= StrOutputParser()

templae1= PromptTemplate(
    template="Generate a joke on {topic}",
    input_variables=['topic']
)

template2=  PromptTemplate(
    template="Explain this joke in nice way {joke}",
    input_variables=["joke"]
)

joke_gen_chain = RunnableSequence(templae1,model, parser)

parallel_chain= RunnableParallel({
    'joke': RunnablePassthrough(),
    'explanation': RunnableSequence(template2,model,parser) 
    })

final_chain= joke_gen_chain | parallel_chain
res=final_chain.invoke({'topic':'Cricket'})
print(res)