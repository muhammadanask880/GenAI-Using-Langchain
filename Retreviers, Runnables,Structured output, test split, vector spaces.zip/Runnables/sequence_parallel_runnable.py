from langchain_huggingface import ChatHuggingFace, HuggingFaceEndpoint
from dotenv import load_dotenv
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
load_dotenv()   
from langchain.schema.runnable import RunnableSequence , RunnableParallel

llm1= HuggingFaceEndpoint(repo_id="meta-llama/Llama-3.1-8B-Instruct", task="text-generation",
                         max_new_tokens=10)     
model = ChatHuggingFace(llm=llm1)

template1 = PromptTemplate(
    template="generate a tweet about {topic}",
    input_variables=['topic']
)

template2 = PromptTemplate(
    template="genrate a linkedin post on {topic}",
    input_variables=['topic']
)

parser1 = StrOutputParser()

parllel_chain = RunnableParallel({
    'tweet': RunnableSequence(template1,model,parser1),
    'linkedin': RunnableSequence(template2,model,parser1)
})

res=parllel_chain.invoke({'topic': 'AI'})
print(res)