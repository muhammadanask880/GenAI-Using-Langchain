from langchain_huggingface import ChatHuggingFace, HuggingFaceEndpoint
from dotenv import load_dotenv
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain.schema.runnable import RunnableSequence , RunnableParallel , RunnablePassthrough, RunnableLambda
load_dotenv()

llm1= HuggingFaceEndpoint(repo_id="meta-llama/Llama-3.1-8B-Instruct", task="text-generation",
                         max_new_tokens=10)     
model = ChatHuggingFace(llm=llm1)
parser= StrOutputParser()

def word(text):
    return len(text.split())

template1 = PromptTemplate(
    template="generate a tweet about {topic}",
    input_variables=['topic']
)

joke_gen_chain= RunnableSequence(template1,model,parser)

parallel_chian = RunnableParallel({
    "joke" : RunnablePassthrough(),
    "Word_cout" : RunnableLambda(word)
})

final_chain = joke_gen_chain | parallel_chian

res= final_chain.invoke({"topic": "AI"})
print(res)


