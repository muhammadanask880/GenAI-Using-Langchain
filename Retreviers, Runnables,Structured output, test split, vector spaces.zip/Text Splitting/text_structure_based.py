#most to use this splitter

from langchain.text_splitter import RecursiveCharacterTextSplitter
text="Artificial Intelligence has rapidly transformed multiple industries, from healthcare and finance to education and entertainment. Large Language Models (LLMs) like GPT are now being integrated into applications such as chatbots, code assistants, and personalized recommendation systems. Despite their impressive capabilities, challenges such as hallucinations, bias, and the need for fine-tuning on domain-specific data remain critical. Researchers are actively exploring retrieval-augmented generation (RAG), vector databases, and efficient model compression techniques to make AI more reliable, scalable, and accessible for real-world use cases"

splitter =RecursiveCharacterTextSplitter(
    chunk_size=300,
    chunk_overlap = 0
)

chunk = splitter.split_text(text)

print(len(chunk))


print(chunk)