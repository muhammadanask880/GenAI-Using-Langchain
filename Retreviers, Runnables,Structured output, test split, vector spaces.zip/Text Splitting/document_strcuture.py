from langchain.text_splitter import RecursiveCharacterTextSplitter, Language

text = """
class Car:
    def __init__(self, brand, model, year):
        self.brand = brand
        self.model = model
        self.year = year
    
    def display_info(self):
        return f"{self.year} {self.brand} {self.model}"
    
    def start_engine(self):
        return f"The {self.brand} {self.model}'s engine has started!"


# Using the class
my_car = Car("Toyota", "Corolla", 2021)

print(my_car.display_info())     # Calls method
print(my_car.start_engine())     # Calls another method

"""

spliter= RecursiveCharacterTextSplitter.from_language(
    language=Language.PYTHON,
    chunk_size=350,
    chunk_overlap=0
)

docs=spliter.split_text(text)

print(docs[0])

print(len(docs))