from langchain_experimental.text_splitter import SemanticChunker

from langchain_huggingface import HuggingFaceEmbeddings
from dotenv import load_dotenv
# from langchain.vectorstores import Chroma
# from langchain_community.vectorstores import Chroma

import os   
load_dotenv()
# embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
# embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")

text= """
Space exploration has advanced rapidly in recent decades, with missions to Mars, 
the Moon, and even asteroids providing valuable insights into the origins of our
solar system. Modern telescopes and rovers have enabled scientists to study distant planets, 
search for signs of water, and better understand the potential for 
extraterrestrial life.


Climate change remains one of the greatest global challenges, as rising
temperatures and extreme weather events continue to impact ecosystems 
and human societies. At the same time, artificial intelligence is being 
applied in fields ranging from healthcare to finance, with machine 
learning models transforming decision-making and automation in ways 
previously unimaginable.
"""

spliter = SemanticChunker(
    HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2"), breakpoint_threshold_type="standard_deviation",
    breakpoint_threshold_amount=0.00000000000000000000000001
)

docs=spliter.create_documents([text])

print(docs)

print(len(docs))