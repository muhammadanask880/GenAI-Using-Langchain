from langchain.text_splitter import CharacterTextSplitter
from langchain.schema import Document

text = "Artificial Intelligence has rapidly transformed multiple industries, from healthcare and finance to education and entertainment. Large Language Models (LLMs) like GPT are now being integrated into applications such as chatbots, code assistants, and personalized recommendation systems. Despite their impressive capabilities, challenges such as hallucinations, bias, and the need for fine-tuning on domain-specific data remain critical. Researchers are actively exploring retrieval-augmented generation (RAG), vector databases, and efficient model compression techniques to make AI more reliable, scalable, and accessible for real-world use cases."

spliter = CharacterTextSplitter(
    chunk_size=100,
    chunk_overlap=0,
    separator=''  
)

# ✅ Splitting plain text
out = spliter.split_text(text)
print(out)

print("**********************")

# ✅ Convert list of strings to list of Documents
docs = [
    Document(page_content="Artificial Intelligence has rapidly transformed multiple industries, from healthcare and finance to education and entertainment. Large Language Models (LLMs) like GPT are now being integrated into applications such as chatbots, code assistants, and personalized recommendation systems. Despite their impressive capabilities, challenges such as hallucinations, bias, and the need for fine-tuning on domain-specific data remain critical. Researchers are actively exploring retrieval-augmented generation (RAG), vector databases, and efficient model compression techniques to make AI more reliable, scalable, and accessible for real-world use cases."),
    Document(page_content="Artificial Intelligence has rapidly transformed multiple industries, from healthcare and finance to education and entertainment. Large Language Models"),
    Document(page_content="(LLMs) like GPT are now being integrated into applications such as chatbots, code assistants, and personalized recommendation systems. Despite their impressive capabilities, challenges such as hallucinations, bias, and the need for fine-tuning on domain-specific data remain critical. Researchers are actively exploring retrieval-augmented generation (RAG), vector databases, and efficient model compression techniques to make AI more reliable, scalable, and accessible for real-world use cases.")
]

out1 = spliter.split_documents(docs)
print(out1)
