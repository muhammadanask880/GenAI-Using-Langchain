from langchain_community.retrievers import WikipediaRetriever

reteriver = WikipediaRetriever(top_k_results=2, lang='en')

query = "What is IPL and PSL?"

docs = reteriver.invoke(query)


for i, doc in enumerate(docs):
    print("result: ", i+1)
    print("Conetent: ", doc.page_content)