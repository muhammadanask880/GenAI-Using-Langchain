from langchain_community.vectorstores import Chroma, FAISS
from langchain_huggingface import HuggingFaceEmbeddings
from dotenv import load_dotenv
from langchain_core.documents import Document
import os   
load_dotenv()
embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")

doc1 = Document(
    page_content="Virat Kohli is one of the greatest modern-day batsmen, known for his aggressive style and consistency in run-chases.",
    metadata={"team": "RCB"}
)

doc2 = Document(
    page_content="MS Dhoni is renowned for his calm captaincy, sharp wicketkeeping skills, and his ability to finish matches under pressure.",
    metadata={"team": "CSK"}
)

documents= [doc1,doc2]

vectorstore = FAISS.from_documents(
    documents=documents,
    embedding=embeddings
)

ret = vectorstore.as_retriever(
    search_type="mmr",
    search_kwargs={"k":3,"lambda_mult":0.5}
)

query= "who is player of RCB?"
result = ret.invoke(query)

for i, doc in enumerate(result):
    print("result: ", i+1)
    print("Conetent: ", doc.page_content)