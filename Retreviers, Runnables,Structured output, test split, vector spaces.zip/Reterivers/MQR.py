from langchain_community.vectorstores import Chroma, FAISS
from langchain_huggingface import ChatHuggingFace, HuggingFaceEndpoint

from langchain_huggingface import HuggingFaceEmbeddings
from dotenv import load_dotenv
from langchain_core.documents import Document
from langchain.retrievers.multi_query import MultiQueryRetriever
import os   
load_dotenv()

llm1=HuggingFaceEndpoint(repo_id="meta-llama/Llama-3.1-8B-Instruct")
model =ChatHuggingFace(llm=llm1)
embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")

# all_docs = [
#     Document(page_content="Regular walking boosts heart health and reduces stress levels.", metadata={"source": "H1"}),
#     Document(page_content="Consuming fruits and vegetables strengthens the immune system and promotes longevity.", metadata={"source": "H2"}),
#     Document(page_content="Deep sleep helps in tissue repair and enhances memory consolidation.", metadata={"source": "H3"}),
#     Document(page_content="Mindfulness and breathing exercises can reduce cortisol and improve mental clarity.", metadata={"source": "H4"}),
#     Document(page_content="Drinking enough water throughout the day keeps metabolism active and skin healthy.", metadata={"source": "H5"}),
#     Document(page_content="The use of solar panels in modern homes lowers carbon emissions and saves energy costs.", metadata={"source": "E1"}),
#     Document(page_content="Python's simplicity and vast libraries make it ideal for data science and machine learning.", metadata={"source": "E2"}),
#     Document(page_content="Photosynthesis allows plants to convert sunlight into chemical energy essential for life.", metadata={"source": "E3"}),
#     Document(page_content="The 2022 FIFA World Cup in Qatar showcased global unity and sports excellence.", metadata={"source": "E4"}),
#     Document(page_content="Black holes distort spacetime and exhibit immense gravitational pull beyond escape.", metadata={"source": "E5"})
# ]


# vectorstore = FAISS.from_documents(
#     documents=all_docs,
#     embedding=embeddings
# )

# similiarity_ret = vectorstore.as_retriever(
#     search_type="similarity",
#     search_kwargs={"k":5}
# )

# multiquery_ret = MultiQueryRetriever.from_llm(
#     retriever=vectorstore.as_retriever(search_kwargs={"k":5}),
#     llm=model
# )

# query = "improve your health"

# sim_res= similiarity_ret.invoke(query)

# multi_res = multiquery_ret.invoke(query)
 

# for i, doc in enumerate(sim_res):
#     print("result: ", i+1)
#     print("Conetent: ", doc.page_content)


# print("*******************")

# for j, new in enumerate(multi_res):
#     print("result: ", j+1)
#     print("Conetent: ", new.page_content)

# Relevant health & wellness documents
all_docs = [
    Document(page_content="Regular walking boosts heart health and can reduce symptoms of depression.", metadata={"source": "H1"}),
    Document(page_content="Consuming leafy greens and fruits helps detox the body and improve longevity.", metadata={"source": "H2"}),
    Document(page_content="Deep sleep is crucial for cellular repair and emotional regulation.", metadata={"source": "H3"}),
    Document(page_content="Mindfulness and controlled breathing lower cortisol and improve mental clarity.", metadata={"source": "H4"}),
    Document(page_content="Drinking sufficient water throughout the day helps maintain metabolism and energy.", metadata={"source": "H5"}),
    Document(page_content="The solar energy system in modern homes helps balance electricity demand.", metadata={"source": "I1"}),
    Document(page_content="Python balances readability with power, making it a popular system design language.", metadata={"source": "I2"}),
    Document(page_content="Photosynthesis enables plants to produce energy by converting sunlight.", metadata={"source": "I3"}),
    Document(page_content="The 2022 FIFA World Cup was held in Qatar and drew global energy and excitement.", metadata={"source": "I4"}),
    Document(page_content="Black holes bend spacetime and store immense gravitational energy.", metadata={"source": "I5"}),
]

vectorstore = FAISS.from_documents(documents=all_docs, embedding=embeddings)

# Create retrievers
similarity_retriever = vectorstore.as_retriever(search_type="similarity", search_kwargs={"k": 5})

multiquery_retriever = MultiQueryRetriever.from_llm(
    retriever=vectorstore.as_retriever(search_kwargs={"k": 5}),
    llm=ChatHuggingFace(llm=llm1)
)

query = "How to improve energy levels and maintain balance?"

similarity_results = similarity_retriever.invoke(query)
multiquery_results= multiquery_retriever.invoke(query)

for i, doc in enumerate(similarity_results):
    print(f"\n--- Result {i+1} ---")
    print(doc.page_content)

print("*"*150)

for i, doc in enumerate(multiquery_results):
    print(f"\n--- Result {i+1} ---")
    print(doc.page_content)